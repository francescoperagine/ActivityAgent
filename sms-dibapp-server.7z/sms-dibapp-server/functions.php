<?php

include 'db_connect.php';
include 'config.php';

define("USER_EXISTS_QUERY", "SELECT count(*) as count FROM user WHERE email = ?");
define("VERIFY_PASSWORD_QUERY", "SELECT passwordHash, salt FROM user WHERE email = ?");
define("GET_ROLE_LIST_QUERY", "SELECT name FROM role ORDER BY name");
define("GET_DEGREECOURSE_LIST_QUERY", "SELECT name FROM degreecourse ORDER BY name");
define("REGISTER_NEW_USER_QUERY", 
	"INSERT INTO user(serialNumber, name, surname, email, passwordHash, salt) VALUES (:serialNumber, :name, :surname, :email, :passwordHash, :salt)");
define("REGISTER_NEW_USER_DEGREECOURSE_QUERY", 
	"INSERT INTO user_degreecourse(userID, degreecourseID) SELECT user.ID, degreecourse.ID FROM user, degreecourse WHERE EMAIL = :email AND degreecourse.name = :degreecourse");
define("REGISTER_NEW_USER_ROLE_QUERY", 
	"UPDATE user SET user.roleID = (SELECT ID from role WHERE name = :roleName) WHERE user.email = :email"); 
define("SET_STUDENT_CAREER_QUERY",
	"INSERT INTO student_career(studentID, classID) 
	SELECT user.ID,degreecourse_class.classID
    FROM user, user_degreecourse, degreecourse, degreecourse_class
    WHERE email = :email
      AND user.ID = user_degreecourse.userID
      AND degreecourse_class.degreecourseID = degreecourse.ID
      AND degreecourse.name = :degreecourse");
define("GET_EXAMS_LIST_QUERY", "SELECT s.ID as classID, c.name as className, c.year as year, c.semester as semester, s.passed as passed, s.passedDate as passedDate, s.vote as vote, s.praise as praise FROM student_career as s, class as c WHERE s.classID = c.ID AND studentID = ? ORDER BY year, className");
define("GET_USER_DETAILS_QUERY", "SELECT * FROM user_detail WHERE email = ?");

	  
class Response {
	
	var $message;
	var $code;
	
	function __construct(string $message, int $code) {
		$this->message = $message;
		$this->code = $code;
	}
}

function login(array $input) {
	if(isset($input['email']) && isset($input['password'])){
		try {
			credentialAreNotNull($input['email'], $input['password']);
			userExists($input['email']);
			verifyPassword($input['email'], $input['password']);	
			$response = new Response(LOGIN_OK_TEXT, LOGIN_OK_CODE);
		} catch( Exception $e) {
			$response = new Response($e->getMessage(), intval($e->getCode())); 
		}
	}
	return($response);
}

function credentialAreNotNull(string $email, string $password) {
	if($email == '' || $password == '') {
		throw new Exception(MISSING_MANDATORY_PARAMETERS_TEXT, MISSING_MANDATORY_PARAMETERS_CODE);
	}	
}

function userExists(string $email){
	global $connection;
	$stmt = $connection->prepare(USER_EXISTS_QUERY);
	$stmt->execute([$email]);
	$result = $stmt->fetch(PDO::FETCH_OBJ);
	if($result->count != 1) throw new Exception(INVALID_EMAIL_TEXT, INVALID_EMAIL_CODE);
}

function verifyPassword(string $email, string $password) {
	global $connection;
	$stmt = $connection->prepare(VERIFY_PASSWORD_QUERY);
	$stmt->execute([$email]);
	$result = $stmt->fetch(PDO::FETCH_OBJ);
	if(!password_verify(concatPasswordWithSalt($password, $result->salt), $result->passwordHash)){
		throw new Exception(INVALID_PASSWORD_TEXT, INVALID_PASSWORD_CODE);
	}
}

function registration(array $input) {
	if(isset($input['name']) && isset($input['surname']) && isset($input['serialNumber']) && isset($input['degreecourse']) && isset($input['roleName']) && isset($input['email']) && isset($input['password'])){
	//Register the user if doesn't exists
		try {
			userExists($input['email']);
			$response = new Response(USER_ALREADY_EXISTS_TEXT, USER_ALREADY_EXISTS_CODE);
		} catch(Exception $e) {
			$response = registerNewUser($input);
		}
	} else { 
		$response = new Response(MISSING_MANDATORY_PARAMETERS_TEXT, MISSING_MANDATORY_PARAMETERS_CODE);
	}
	return $response;
}

function getRoleList() {
	global $connection;
	$stmt = $connection->prepare(GET_ROLE_LIST_QUERY);
	$stmt->execute();
	$response = $stmt->fetchAll(PDO::FETCH_OBJ);
	return $response;
}

function getDegreecourseList() {
	global $connection;
	$stmt = $connection->prepare(GET_DEGREECOURSE_LIST_QUERY);
	$stmt->execute();
	$response = $stmt->fetchAll(PDO::FETCH_OBJ);
	return $response;
}

function registerNewUser(array $input) {
	global $connection;
	//Get a unique Salt
	$salt = getSalt();
	//Generate a unique password Hash
	$passwordHash = password_hash(concatPasswordWithSalt($input['password'],$salt),PASSWORD_DEFAULT);
	$response = null;
	
	//Query to register new user
	$stmt1 = $connection->prepare(REGISTER_NEW_USER_QUERY);
	$stmt1->bindValue(':name', $input['name']);
	$stmt1->bindValue(':surname', $input['surname']);
	$stmt1->bindValue(':serialNumber', $input['serialNumber']);
	$stmt1->bindValue(':email', $input['email']);
	$stmt1->bindValue(':passwordHash', $passwordHash);
	$stmt1->bindValue(':salt', $salt);
	
	$stmt2 = $connection->prepare(REGISTER_NEW_USER_DEGREECOURSE_QUERY);
	$stmt2->bindValue(':email', $input['email']);
	$stmt2->bindValue(':degreecourse', $input['degreecourse']);

	$stmt3 = $connection->prepare(REGISTER_NEW_USER_ROLE_QUERY);
	$stmt3->bindValue(':email', $input['email']);
	$stmt3->bindValue(':roleName', $input['roleName']);
	
	$stmt4 = $connection->prepare(SET_STUDENT_CAREER_QUERY);
	$stmt4->bindValue(':email', $input['email']);
	$stmt4->bindValue(':degreecourse', $input['degreecourse']);
	
	switch ($input['roleName']) {
		case USER_ROLE_STUDENT: 
			$connection->beginTransaction();
			if($stmt1->execute() && $stmt2->execute() && $stmt3->execute() && $stmt4->execute()){
				$connection->commit();
				$response = new Response(USER_CREATED_TEXT,USER_CREATED_CODE);
			} else {
				$connection->rollBack();
				$response = new Response(USER_NOT_CREATED_TEXT,USER_NOT_CREATED_CODE);
			} 
			break;
		case USER_ROLE_BACKOFFICE_OPERATOR:
		case USER_ROLE_TEACHER:	
			$connection->beginTransaction();
			if( $stmt1->execute() && $stmt2->execute() && $stmt3->execute()){
				$connection->commit();
				$response = new Response(USER_CREATED_TEXT,USER_CREATED_CODE);
			} else {
				$connection->rollBack();
				$response = new Response(USER_NOT_CREATED_TEXT,USER_NOT_CREATED_CODE);
			}
				
		default: break;
	}
	return $response;
}

function getUserDetails(string $email) {
	global $connection;
	$stmt = $connection->prepare(GET_USER_DETAILS_QUERY);
	$stmt->execute([$email]);
	$response = $stmt->fetch(PDO::FETCH_OBJ);
	return $response;
}

function getExamsList(string $email) {
	global $connection;
	$stmt = $connection->prepare(GET_EXAMS_LIST_QUERY);
	$stmt->execute([$email]);
	$response = $stmt->fetchAll(PDO::FETCH_OBJ);
	return $response;
}

/**
* Creates a unique Salt for hashing the password
* 
* @return
*/

$random_salt_length = 32;

function getSalt(){
	global $random_salt_length;
	return bin2hex(openssl_random_pseudo_bytes($random_salt_length));
}

/**
* Creates password hash using the Salt and the password
* 
* @param $password
* @param $salt
* 
* @return
*/

function concatPasswordWithSalt($password, $salt){
	global $random_salt_length;
	if($random_salt_length % 2 == 0){
		$mid = $random_salt_length / 2;
	} else {
		$mid = ($random_salt_length - 1) / 2;
	}
	return substr($salt,0,$mid - 1).$password.substr($salt,$mid,$random_salt_length - 1);
}

// ATTENDANCE

function setAttendance($user, $lecture) {

}

// returns true if the attendance is already registered

function attendanceIsSet($user, $lecture) {

}

// RATING

function setRating($user, $lecture, $rating) {

}

// returns true if the rating is already registered

function ratingIsSet($user, $lecture, $rating) {

}

// SUMMARY

function setSummary($user, $lecture, $summary) {

}

// returns true if the summary is already registered

function summaryIsSet($user, $lecture, $summary) {

}

// REVIEW

function setReview($user, $lecture, $review) {

}

// returns true if the review is already registered

function reviewIsSet($user, $lecture, $review) {

}

?>